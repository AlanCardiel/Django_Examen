from django.contrib import admin
from apps.cliente.models import Cliente
# Register your models here.

admin.site.register(Cliente)