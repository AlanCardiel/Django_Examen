from django import forms
from apps.cliente.models import Cliente

class Cliente_Form(forms.ModelForm):
	class Meta:
		model = Cliente
		fields = [
				'nombre',
				'apellidos',
				'edad',
				'sexo',
				'RFC',
				'direccion',
				'telefono' ,
		]
		labels = {
			'nombre': 'Nombre',
			'apellidos': 'Apellidos',
			'edad': 'Edad',
			'sexo': 'Sexo',
			'RFC': 'rfc',
			'direccion': 'Direccion',
			'telefono' : 'Telefono',

		}
		widgets = {
			'nombre': forms.TextInput(attrs={'class':'form-control'}),
			'apellidos': forms.TextInput(attrs={'class':'form-control'}),
			'edad': forms.TextInput(attrs={'class':'form-control'}),
			'sexo': forms.TextInput(attrs={'class':'form-control'}),
			'RFC': forms.TextInput(attrs={'class':'form-control'}),
			'direccion': forms.TextInput(attrs={'class':'form-control'}),
			'telefono' : forms.TextInput(attrs={'class':'form-control'}),


		}