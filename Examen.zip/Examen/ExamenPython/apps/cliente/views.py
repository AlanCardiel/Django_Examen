from django.shortcuts import render, redirect
from django.http import HttpResponse
from apps.cliente.forms import Cliente_Form
# Create your views here.

def index(request):
	return render (request, "cliente/index.html")

def cliente_view(request):
	if request.method == 'POST':
		form = Cliente_Form(request.POST)
		if form.is_valid():
			form.save()
		return redirect('/cliente')
	else:
		form = Cliente_Form()
	return render(request, 'cliente/cliente_form.html', {'form':form})