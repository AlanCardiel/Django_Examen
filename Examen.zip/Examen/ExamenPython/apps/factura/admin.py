from django.contrib import admin
from apps.factura.models import Factura
# Register your models here.

admin.site.register(Factura)