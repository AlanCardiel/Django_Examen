from django.apps import AppConfig


class FacturaConfig(AppConfig):
    name = 'factura'
