from django import forms
from apps.factura.models import Factura

class Factura_Form(forms.ModelForm):
	class Meta:
		model = Factura
		fields = [
			'num_Fac',
			'cliente',
			'producto',
		]
		labels = {
			'num_Fac': 'Num_Fac',
			'cliente': 'Cliente',
			'producto': 'Producto',

		}
		widgets = {
			'num_Fac': forms.TextInput(attrs={'class':'form-control'}),
			'cliente': forms.Select(attrs={'class':'form-control'}),
			'producto': forms.CheckboxSelectMultiple(),
		}