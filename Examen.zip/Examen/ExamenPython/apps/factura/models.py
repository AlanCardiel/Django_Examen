from django.db import models
from apps.cliente.models import Cliente
from apps.producto.models import Producto
# Create your models here.

class Factura(models.Model):
	num_Fac = models.CharField(max_length=50)
	cliente = models.ForeignKey(Cliente, null=True, blank=True, on_delete=models.CASCADE)
	producto = models.ManyToManyField(Producto)