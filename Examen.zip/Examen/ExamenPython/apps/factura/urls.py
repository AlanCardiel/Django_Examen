from django.conf.urls import url
from apps.factura.views import index_factura, factura_view

urlpatterns = [
    url(r"^$", index_factura, name= 'index_factura'),
    url(r'^nuevo$', factura_view, name= 'factura_view'),
]