from django.shortcuts import render, redirect
from django.http import HttpResponse
from apps.factura.forms import Factura_Form
# Create your views here.

def index_factura(request):
	return render (request, "factura/index.html")

def factura_view(request):
	if request.method == 'POST':
		form = Factura_Form(request.POST)
		if form.is_valid():
			form.save()
		return redirect('/factura')
	else:
		form = Factura_Form()
	return render(request, 'factura/factura.html',{'form':form})