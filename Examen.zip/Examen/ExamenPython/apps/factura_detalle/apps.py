from django.apps import AppConfig


class FacturaDetalleConfig(AppConfig):
    name = 'factura_detalle'
