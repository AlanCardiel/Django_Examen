from django.conf.urls import url, include
from apps.principal.views import index_principal

urlpatterns = [
    url(r'^$', index_principal),
]