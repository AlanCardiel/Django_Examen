from django import forms
from apps.producto.models import Producto

class Producto_Form(forms.ModelForm):
	class Meta:
		model = Producto
		fields = [
			'nombre',
			'descripcion',
			'precio',
			'cantidad',
		]
		labels = {
			'nombre': 'Nombre',
			'descripcion': 'Descripcion',
			'precio': 'Precio',
			'cantidad': 'Cantidad',

		}
		widgets = {
			'nombre': forms.TextInput(attrs={'class':'form-control'}),
			'descripcion': forms.TextInput(attrs={'class':'form-control'}),
			'precio': forms.TextInput(attrs={'class':'form-control'}),
			'cantidad': forms.TextInput(attrs={'class':'form-control'}),

		}