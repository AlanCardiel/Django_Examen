from django.conf.urls import url, include
from apps.producto.views import index_producto, producto_view

urlpatterns = [
    url(r'^$', index_producto, name= 'index_producto'),
    url(r'^nuevo$', producto_view, name= 'producto_view'),
]