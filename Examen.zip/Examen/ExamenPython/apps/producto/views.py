from django.shortcuts import render, redirect
from django.http import HttpResponse
from apps.producto.forms import Producto_Form
# Create your views here.

def index_producto(request):
	return render (request, "producto/index.html")

def producto_view(request):
	if request.method == 'POST':
		form = Producto_Form(request.POST)
		if form.is_valid():
			form.save()
		return redirect('/producto')
	else:
		form = Producto_Form()
	return render(request, 'producto/producto.html',{'form':form})